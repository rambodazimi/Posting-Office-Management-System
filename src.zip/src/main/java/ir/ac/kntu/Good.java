
public class Good {

	
	String name;
	int sender, giver;
	int ship;		//1=marine		2=ground		3=air
	int post;		//1=normal		2=special
	String status;		//1=ordered		2=sent			3=delivered
	
	
}
