
public class Customer {

	String firstName;
	String lastName;
	int id;
	int numberOfOrder = 0;
	
}
