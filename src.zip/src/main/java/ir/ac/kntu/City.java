
public class City {

	String name;
	int coordination;	//distance from Tehran(Source)
}
